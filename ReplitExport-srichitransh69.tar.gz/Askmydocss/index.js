import express from 'express';
import dotenv from 'dotenv';
import multer from 'multer';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import pdfParse from 'pdf-parse/lib/pdf-parse.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 5000;
const HOST = '0.0.0.0';

const upload = multer({
  dest: 'uploads/',
  limits: { fileSize: 20 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (file.mimetype === 'application/pdf') cb(null, true);
    else cb(new Error('Only PDF files are allowed'));
  }
});

if (!fs.existsSync('uploads')) fs.mkdirSync('uploads');

app.use(express.json());
app.use(express.static('.'));

const sessions = {};

app.post('/upload', upload.single('pdf'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No PDF uploaded' });

    const dataBuffer = fs.readFileSync(req.file.path);
    const data = await pdfParse(dataBuffer);
    fs.unlinkSync(req.file.path);

    const text = data.text.trim();
    if (!text) return res.status(400).json({ error: 'Could not extract text from PDF' });

    const chunkSize = 800;
    const overlap = 100;
    const chunks = [];
    for (let i = 0; i < text.length; i += chunkSize - overlap) {
      chunks.push(text.slice(i, i + chunkSize));
      if (i + chunkSize >= text.length) break;
    }

    const sessionId = Date.now().toString();
    sessions[sessionId] = {
      chunks,
      fullText: text.slice(0, 3000),
      filename: req.file.originalname,
      pages: data.numpages
    };

    res.json({ sessionId, filename: req.file.originalname, pages: data.numpages, chars: text.length });
  } catch (err) {
    console.error('Upload error:', err);
    res.status(500).json({ error: err.message || 'Failed to process PDF' });
  }
});

app.post('/chat', async (req, res) => {
  try {
    const { sessionId, question, history } = req.body;
    if (!sessionId || !question) return res.status(400).json({ error: 'Missing sessionId or question' });

    const session = sessions[sessionId];
    if (!session) return res.status(404).json({ error: 'Session not found. Please re-upload your PDF.' });

    const apiKey = process.env.GROQ_API_KEY;
    if (!apiKey) return res.status(500).json({ error: 'GROQ_API_KEY not set. Please add it in Secrets.' });

    const keywords = question.toLowerCase().split(/\s+/).filter(w => w.length > 3);
    const scored = session.chunks.map((chunk, i) => {
      const lower = chunk.toLowerCase();
      const score = keywords.reduce((s, kw) => s + (lower.includes(kw) ? 1 : 0), 0);
      return { chunk, score, i };
    });
    scored.sort((a, b) => b.score - a.score || a.i - b.i);
    const topChunks = scored.slice(0, 3).sort((a, b) => a.i - b.i).map(x => x.chunk);
    const context = topChunks.join('\n\n').slice(0, 2500);

    const messages = [
      {
        role: 'system',
        content: `You are a helpful assistant answering questions about "${session.filename}". Use only the excerpt below. Be concise. If the answer isn't in the excerpt, say so.\n\nEXCERPT:\n${context}`
      }
    ];

    if (history && Array.isArray(history)) {
      for (const msg of history.slice(-2)) {
        messages.push(msg);
      }
    }

    messages.push({ role: 'user', content: question });

    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`
      },
      body: JSON.stringify({
        model: 'llama-3.1-8b-instant',
        messages,
        max_tokens: 512,
        temperature: 0.3
      })
    });

    if (!response.ok) {
      const err = await response.json();
      return res.status(500).json({ error: err.error?.message || 'Groq API error' });
    }

    const data = await response.json();
    const answer = data.choices[0].message.content;
    res.json({ answer });
  } catch (err) {
    console.error('Chat error:', err);
    res.status(500).json({ error: err.message || 'Failed to get answer' });
  }
});

async function groqChat(apiKey, messages, maxTokens = 400) {
  const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
    body: JSON.stringify({ model: 'llama-3.1-8b-instant', messages, max_tokens: maxTokens, temperature: 0.3 })
  });
  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error?.message || 'Groq API error');
  }
  const data = await response.json();
  return data.choices[0].message.content;
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

app.post('/summarize', async (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  const send = (data) => res.write(`data: ${JSON.stringify(data)}\n\n`);

  try {
    const { sessionId } = req.body;
    if (!sessionId) { send({ error: 'Missing sessionId' }); return res.end(); }

    const session = sessions[sessionId];
    if (!session) { send({ error: 'Session not found. Please re-upload your PDF.' }); return res.end(); }

    const apiKey = process.env.GROQ_API_KEY;
    if (!apiKey) { send({ error: 'GROQ_API_KEY not set.' }); return res.end(); }

    const fullText = session.chunks.join(' ');
    const sectionSize = 2000;
    const sections = [];
    for (let i = 0; i < fullText.length; i += sectionSize) {
      sections.push(fullText.slice(i, i + sectionSize));
      if (sections.length >= 5) break;
    }

    send({ status: `Summarizing ${sections.length} section${sections.length > 1 ? 's' : ''}…`, total: sections.length, done: 0 });

    const miniSummaries = [];
    for (let i = 0; i < sections.length; i++) {
      if (i > 0) await sleep(2000);
      send({ status: `Processing section ${i + 1} of ${sections.length}…`, total: sections.length, done: i });
      const summary = await groqChat(apiKey, [
        { role: 'system', content: 'Summarize the following text excerpt in 3-5 concise bullet points. Be direct, no preamble.' },
        { role: 'user', content: sections[i] }
      ], 300);
      miniSummaries.push(summary);
    }

    send({ status: 'Combining sections…', total: sections.length, done: sections.length });

    if (miniSummaries.length === 1) {
      send({ done: true, summary: miniSummaries[0] });
    } else {
      await sleep(1500);
      const combined = await groqChat(apiKey, [
        { role: 'system', content: `You are summarizing the document "${session.filename}". Below are section summaries. Write a single clear summary with key points as bullet points. No preamble.` },
        { role: 'user', content: miniSummaries.join('\n\n---\n\n') }
      ], 450);
      send({ done: true, summary: combined });
    }

    res.end();
  } catch (err) {
    send({ error: err.message || 'Summarization failed' });
    res.end();
  }
});

app.listen(PORT, HOST, () => console.log(`AskMyDocs running on http://${HOST}:${PORT}`));

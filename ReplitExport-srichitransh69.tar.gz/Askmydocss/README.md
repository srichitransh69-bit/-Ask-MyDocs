# AskMyDocs

A powerful AI-powered PDF chatbot built with LangChain.

## Setup

1. Clone or download this repository.
2. Run `npm install` to install dependencies.
3. Copy `.env.example` to `.env` and add your OpenAI API key.
4. Start the server: `npm run dev`
5. Access the client via your browser.

---
Developed by **Chitransh Srivastava**
